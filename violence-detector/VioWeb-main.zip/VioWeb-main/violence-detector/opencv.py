import cv2 as c

